import React from "react";

const ViewProfileComponents = (props) => {
  return <h1>View Profile</h1>;
};

export default ViewProfileComponents;
