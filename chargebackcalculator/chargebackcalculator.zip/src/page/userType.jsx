import React from "react";
import UserTypeComponents from "../components/userType.components";

const userType = () => {
  return (
    <div>
      <div>
        <UserTypeComponents />
      </div>
    </div>
  );
};

export default userType;
