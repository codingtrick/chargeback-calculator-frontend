import React from "react";
import IssueComponents from "../components/issue.components";

const Issue = () => {
  return (
    <div>
      <div>
        <IssueComponents />
      </div>
    </div>
  );
};

export default Issue;
