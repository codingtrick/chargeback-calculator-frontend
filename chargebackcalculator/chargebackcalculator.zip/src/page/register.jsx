import React from "react";
import RegisterComponents from "../components/register.components";

const Register = () => {
  return (
    <div>
      <div>
        <RegisterComponents />
      </div>
    </div>
  );
};

export default Register;
