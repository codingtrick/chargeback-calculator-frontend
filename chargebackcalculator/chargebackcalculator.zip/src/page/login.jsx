import React from "react";
import LoginComponents from "../components/login.components";

const Login = () => {
  return (
    <div>
      <div>
        <LoginComponents />
      </div>
    </div>
  );
};

export default Login;
