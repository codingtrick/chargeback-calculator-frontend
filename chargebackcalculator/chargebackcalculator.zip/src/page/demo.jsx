import React from "react";
import DemoComponents from "../components/demo.components";

const Demo = () => {
  return <DemoComponents />;
};

export default Demo;
