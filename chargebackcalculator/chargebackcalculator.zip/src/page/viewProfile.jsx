import React from "react";
import ViewProfileComponents from "../components/viewProfile.components";

const ViewProfile = () => {
  return (
    <div>
      <div>
        <ViewProfileComponents />
      </div>
    </div>
  );
};

export default ViewProfile;
