import React from "react";
import HomeComponents from "../components/Home.components";

const Home = () => {
  return (
    <>
      <HomeComponents />
    </>
  );
};

export default Home;
